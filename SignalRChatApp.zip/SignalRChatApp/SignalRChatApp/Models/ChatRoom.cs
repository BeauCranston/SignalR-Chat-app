﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace SignalRChatApp.Models
{
    public class ChatRoom
    {
        [Key]
        public Guid RoomId { get; set; }
        public string RoomName { get; set; }

        //a foreign key reference to the "RoomIdRef" in the chat message table

        [ForeignKey("RoomIdRef")]
        public ICollection<ChatMessage> ChatMessageList { get; set; }
    }
}
