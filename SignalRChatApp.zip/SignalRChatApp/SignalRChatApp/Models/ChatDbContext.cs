﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SignalRChatApp.Models
{
    public class ChatDbContext:DbContext
    {

        public ChatDbContext(DbContextOptions<ChatDbContext> options):base(options)
        { 
           
        
        }

        protected override void OnModelCreating(ModelBuilder builder)
        {

            
            base.OnModelCreating(builder);

        }

        //for creating the chat messages table
        public DbSet<ChatMessage> ChatMessages { get; set; }

        //for creating the chat rooms table
        public DbSet<ChatRoom> ChatRooms { get; set; }



    }
}
