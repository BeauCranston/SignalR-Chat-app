﻿using SignalRChatApp.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace SignalRChatApp
{
    public class ChatMessage
    {
        [Key]
        //primary key of the chat message table
        public Guid Id { get; set; }
        public string Username { get; set; }
        public string Text { get; set; }
        public DateTimeOffset TimeSent { get; set; }

        //foreign key of the chat message table which establishes a relationship to the chat room table
        public Guid RoomIdRef { get; set; }

        public ChatMessage(string username, string text, DateTimeOffset timeSent)
        {
            Username = username;
            Text = text;
            TimeSent = timeSent;
        }

        //a chat room object reference to satisfy entity frameworks weird way of establishing foreign keys
        public ChatRoom ChatRoom{get; set;}
    }
}
