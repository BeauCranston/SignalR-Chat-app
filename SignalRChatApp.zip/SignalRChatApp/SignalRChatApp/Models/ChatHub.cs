﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using SignalRChatApp.Models;
using Microsoft.AspNetCore.SignalR;
namespace SignalRChatApp
{
    public class ChatHub : Hub
    {
        private readonly ChatDbContext dbContext;
        //dictionary for holding all of the active users in a chat room. uses the connection id as a key and the user name as the value 
        private static ConcurrentDictionary<string, string> activeUsers = new ConcurrentDictionary<string, string>();
        //dictionary for holding all of the active chat rooms. uses the chatroom name as the key and the chatroom object as the value
        private static ConcurrentDictionary<string, ChatRoom> activeChatRooms = new ConcurrentDictionary<string, ChatRoom>();
       


        public ChatHub(ChatDbContext dbContext)
        {
            this.dbContext = dbContext;
        }
        /// <summary>
        /// a method that pulls all of the chat rooms and adds it to the dictionary so that the program can check what room a user is in, or if the program needs to create a new room based on 
        /// what the user inputs into the room name text input in the site.js file.
        /// </summary>
        public void PullAllRooms()
        {
            //grab all of the chat rooms that have a chat room name that is not null
            List<ChatRoom> chatRooms =  dbContext.ChatRooms.Where(chatRoom => chatRoom.RoomName != null).ToList();

            
            //for each of the chat rooms add it to the chat rooms dictionary
            foreach (var room in chatRooms)
            {
                activeChatRooms.TryAdd(room.RoomName, room);
            }
           
        }

        /// <summary>
        /// a method that checks if a client has connected to the webpage. Once a client is connected the method will call the PullAllRooms() method so that the user can join any active chat room,
        /// and sends out a welcome message to the client
        /// </summary>
        /// <returns> does not resturn anything but performs an asyn task</returns>
        public override async Task OnConnectedAsync()
        {
            PullAllRooms();
            await Clients.Caller.SendAsync("ReceiveMessage", "Chat Hub", "Welcome to QuickChat!", DateTimeOffset.UtcNow);


            await base.OnConnectedAsync();
        }


        /// <summary>
        /// a method that is called once a user disconnects from the webpage. The method removes the user from the active users list and sends out a brodcast message that tells the clients that the user has left 
        /// </summary>
        /// <param name="ex"></param>
        /// <returns></returns>
        public override async Task OnDisconnectedAsync(Exception ex)
        {
            string userLeftName = "Unknown User";
            activeUsers.TryRemove(Context.ConnectionId, out userLeftName);
            await Clients.All.SendAsync("ReceiveMessage", "Chat Hub", DateTimeOffset.UtcNow, $"{userLeftName} left the conversation");

            await base.OnDisconnectedAsync(ex);
        }

        /// <summary>
        /// a method that is called when a client joins a room. The method gives the client a connection id, then changes the room name to lowercase so that the roomnames are case insensitve 
        /// so that no matter what case the client uses they will join the room based on the room name alone.
        /// 
        /// the method then checks to see if the room name is listied inside of the dictionary.
        /// 
        /// if the room is listed in the dictionary then the progrma will treat it as existing room and pull the chat history from that room and connect the client to that chatroom.
        /// 
        /// otherwise the program will make a brand new room, push the room to the chatroom table in the database and connect the client to that brand new room
        /// 
        /// in both cases the method will send the client a message letting the client know that they have joined a specific room and add the connectionid of that client to the group so that 
        /// messages in that chatroom only will be received by the client.
        /// 
        /// </summary>
        /// <param name="roomName"></param>
        /// <returns></returns>
        public async Task OnRoomJoin(string roomName)
        {
            //creates a connection id
            string connectionId = Context.ConnectionId;
            roomName = roomName.ToLower();
            
            if (activeChatRooms.ContainsKey(roomName))
            {
                //send welcom message to user 
                await Clients.Caller.SendAsync("ReceiveMessage", "Chat Hub", $"You joined room: {roomName}!", DateTimeOffset.UtcNow);
                //set exisiting chat room to null (if you set the chat room to a new chat room then a new room id will be created and that will cause problems in the db)
                ChatRoom existingChatRoom = null;
                //attempts to push a chat room object to the existingChatRoom variable based on the roomName passed into the method
                activeChatRooms.TryGetValue(roomName, out existingChatRoom);
                //grabs all chat messages that have the same room id as the existing chat room that the client is trying to connect to
                List<ChatMessage> chatMessages = dbContext.ChatMessages.Where(chatMessage=> chatMessage.RoomIdRef == existingChatRoom.RoomId).ToList();
                Debug.WriteLine(chatMessages.Count);
                //for each of the chat messages in the list send them to the client
                foreach (var chatMessage in chatMessages)
                {
                    await Clients.Caller.SendAsync("ReceiveMessage", chatMessage.Username, chatMessage.Text, chatMessage.TimeSent);
                }
                //try to add the existing room just in case it is not in the active chatroom list 
                activeChatRooms.TryAdd(roomName, existingChatRoom);
                
            }
            else
            {
                //creates a new chat room with the same name as the roomName provided in the method argument
                ChatRoom newRoom = new ChatRoom()
                {
                    RoomName = roomName,
                    

                };
                
                //add the new chat room to the active chatroom dictionary
                activeChatRooms.TryAdd(roomName, newRoom);
                //add the chatroom to the database 
                await dbContext.ChatRooms.AddAsync(newRoom);
                //save the chat room to the database
                await dbContext.SaveChangesAsync();
                //send message to client to indicate to the user that the user has joined the chatroom
                await Clients.Caller.SendAsync("ReceiveMessage", "Chat Hub", $"You joined room: {roomName}!", DateTimeOffset.UtcNow);
            }
            // add the users connection id to the group 
            await Groups.AddToGroupAsync(Context.ConnectionId, roomName);

            
        }

        /// <summary>
        /// a method that is called whenever a message is sent in the chatroom page.
        /// checks if the user is not an active user and if that is the case the method will add the user to the active users dictionary.
        /// 
        /// get the chat room that the message will be sent to by going through the active chat rooms dictionary and grabbing the chat room that has tthe same roomName as the one specified
        /// in the method argument.
        /// 
        /// the method then saves the message to the database and sends the message to all clients that are connected to the chatroom.
        /// 
        /// </summary>
        /// <param name="roomName"></param>
        /// <param name="user"></param>
        /// <param name="message"></param>
        /// <returns></returns>
        public async Task SendMessage(string roomName, string user, string message)
        {
            if (!activeUsers.ContainsKey(Context.ConnectionId))
            {
                activeUsers.TryAdd(Context.ConnectionId, user);
            }
            ChatMessage chatMessage = new ChatMessage(user, message, DateTimeOffset.UtcNow);
            ChatRoom currentRoom = null;
            activeChatRooms.TryGetValue(roomName, out currentRoom);
            chatMessage.RoomIdRef = currentRoom.RoomId;
            dbContext.ChatMessages.Add(chatMessage);
            var dbTask = dbContext.SaveChangesAsync();


            await Clients.Group(currentRoom.RoomName.ToLower()).SendAsync("ReceiveMessage", chatMessage.Username, chatMessage.Text);

            await dbTask;
        }

        
    }
}
