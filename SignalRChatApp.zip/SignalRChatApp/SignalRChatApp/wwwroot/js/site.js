﻿//create a connection for signal r

var userName;
var roomName;
var connection = new signalR.HubConnectionBuilder().withUrl("/chatHub").build();
//regex to determine if the message is url or not 
let websiteRegEx = new RegExp("^(http:\/\/www\.|https:\/\/www\.|http:\/\/|https:\/\/)?[a-z0-9]+([\-\.]{1}[a-z0-9]+)*\.[a-z]{2,5}(:[0-9]{1,5})?(\/.*)?$");
//if the chat hub receives a message then call the display message function 
connection.on('ReceiveMessage', displayMessage);
//call the say goodvye function when the connection closes 
connection.onclose(sayGoodbye);

connection.start();

var sendBtn = document.getElementById("btnSend");
//when the send button is clicked check if the user input for the message is valid, if it is cal lthe send message function, if not then display the message error
sendBtn.addEventListener('click', function (e) {
    e.preventDefault();

    var userMessage = document.getElementById('userMessage');
    var text = userMessage.value;
    //the text of the user name
    userName = document.getElementById('username').value;
    //the text of the room name
    roomName = document.getElementById('roomName').value;

   
    var messageError = document.getElementById("messageError");
    //if there is no message in the message text input the message will not send 
    if (userMessage.length < 1) {
        messageError.style.display = "block";
    }

    else {
        userMessage.value = '';
        sendMessage(roomName, userName, text);
    }
    
});

//grabs the element of the user name to be used for the on input listener
var userDom = document.getElementById("username");
//grabs the element of the send button so that it can be manipulated within the on input listener
var sendBtn = document.getElementById("btnSend");
userDom.addEventListener("input", function (e) {
    //the element for the user name error message 
    var userError = document.getElementById("usernameError");
    //if the user neame is > 0 and <= 10 the send mesage will be enabled since the user has a valid name 

    if (userDom.value.length > 0 && userDom.value.length <= 10) {
        
        userError.style.display = "none";
        sendBtn.disabled = false;
    }
    //otherwise the user error message will display and the user wont be able to send a message 
    else {
        
        userError.style.display = "block";
        sendBtn.disabled = true;
    }

});

//element for the room name
var roomDom = document.getElementById("roomName");
//an input event listener for checking if the room name is valid. If the room name is empty the user can not join the room 
roomDom.addEventListener("input", function () {
    var joinBtn = document.getElementById("btnJoin");
    if (roomDom.value.length < 1) {
        joinBtn.disabled = true;
    }
    else {
        joinBtn.disabled = false;
    }
    

    
});


//if the message is not null and has a length then the hub will invoke the 'Send Message' method 
function sendMessage(roomName, userName, message) {
    if (message && message.length) {
        connection.invoke('SendMessage', roomName, userName, message);
    }
}

// this is a method to display the message sent by the user to all of the users within the chat room
function displayMessage(name, message, time) {

    //this is a special css class that is set depending on who is viewing the message and who sent the messae
    var specialClass = userName === name ? "sender" : "recipient";
    switch (name) {
        //if the user name is 'Chat Hub' then the class that is appended to the message class list is 'systemUser' which has its own styling 
        case "Chat Hub":
            specialClass = "systemUser";
            break;
        //if the name is 'Sender' then the class that is appended to the message class list is 'sender' which has its own styling 
        case userName:
            specialClass = "sender";
            break;
        //otehrwise the name is 'recipient' and the class that is appended to the message class list is 'recipient' which has its own styling 
        default:
            specialClass = "recipient";
    }

    //friendly time is a user friendly time stamp that takes the DateTime.UTCNow and converts it to a format the average person can understand
    var friendlyTime = moment(time).format('H:mm:ss');

    //user li is a list item that is appended to the ul element on the page. The user li contains the user name and the time the message was sent 
    var userLi = document.createElement('li');
    userLi.class = 'userLi list-group-item ';
    //the userLi adds the special class to it to differentiate the message from the other message categories 
    userLi.classList.add(specialClass);
    userLi.textContent = friendlyTime + ", " + name + " says:";
    //the message li is the content of the message and is appended to the ul element on the page.
    var MessageLi = document.createElement('li');
    MessageLi.className = 'messageLi list-group-item pl-5 ';
    //the message adds the special class to it to differentiate the message from the other message categories 
    MessageLi.classList.add(specialClass);

    //if the Regex accepts message that is sent to the message parameter in the method then the program will treat it as a URL 
    if (websiteRegEx.test(message) === true) {
        //if the message URL contains jpg or png then the url is treated as an image and will be appended to the message list item as a child.
        //TO TEST THIS GO TO GOOGLE IMAGES, RIGHT CLICK ON THE IMAGE, AND CLICK "Copy image address" AND PASTE THAT URL INTO THE MESSAGE INPUT 
        if (String(message).includes(".jpg") || String(message).includes(".png") || String(message).includes(".jpeg") || String(message).includes(".bmp") || String(message).includes(".gif")  ) {
            var messageImg = document.createElement('img');
            messageImg.src = String(message);
            MessageLi.appendChild(messageImg);

        }
        //otherwise the url is handled as a regular website url and when clicked it will take the user to the webpage that was sent
        else {
            var messageLink = document.createElement('a');
            messageLink.href = String(message);
            messageLink.text = message;
            MessageLi.appendChild(messageLink);
        }
    }
    //if the message is not a url then it is a regular text message and will be treated as such
    else {
        MessageLi.textContent = message;
    }
    
    //grabs the element that contains the ul
    var chatHistoryUl = document.getElementById('chatHistory');
    //appeneds the user message to the list 
    chatHistoryUl.appendChild(userLi);
    //appends the message container to the list along with its children
    chatHistoryUl.appendChild(MessageLi);

    //scroll to the newest message
    $("#chatHistory").animate({ scrollTop: $('#chatHistory').prop('scrollHeight') }, 50);
}

//when a user leaves display the message for disconnecting
function sayGoodbye() {

    connection.invoke(userName);

}

//an event handler that calls a function for when the user clicks the join button
document.getElementById("btnJoin").addEventListener('click', function (e) {
    e.preventDefault();

    var roomName = document.getElementById('roomName').value;
    var roomError = document.getElementById('roomError');
    //if the roomname text input is not null and has alength then the button will not be disabled and when the button is clicked it will put the user into a chat room
    if (roomName && roomName.length) {
        document.getElementById("btnJoin").disabled = true;
        connection.invoke('OnRoomJoin', roomName);
    }
    //if the user tries to enter an empty room the error message will display and the user will nto be able to join the room
    else {
        roomError.style.display = "block";
    }
});



